// @ts-check
const {test, expect, firefox} = require('@playwright/test');

function dump(arr) {
    require('fs').writeFile(
        './dump.json',
        JSON.stringify(arr),
        function (err) {
            if (err) {
                console.error('Crap happens');
            }
        }
    );
}

let products = [];

class Product {
    constructor(product_name,
                product_url,
                product_rating,
                product_price,
                product_revenue) {
        this.product_name = product_name;
        this.product_url = product_url;
        this.product_rating = product_rating;
        this.product_price = product_price;
        this.product_revenue = product_revenue;
    }
}

const delay = ms => new Promise(res => setTimeout(res, ms));

async function scrollDown(page, step = 70) {
    while (step--) {
        await page.mouse.wheel(0, 100);
        await delay(50);
    }
}

async function loadNextPage(tab, pageNum) {
    let navigation = tab.locator('[role="navigation"]');
    let aTags = await navigation.locator('[class="shopee-button-no-outline"]').all();
    for (let i=0;i<aTags.length;i++) {
        let a = aTags[i];
        let texts = await a.allInnerTexts();
        if (texts[0] === pageNum.toString()) await a.click();
    }
}
async function getProducts(tab, curPage = 1) {
    // Chờ tới khi các sản phẩm được load ra
    await scrollDown(tab);
    while (await tab.locator('ul.shopee-search-item-result__items').count() === 0) await delay(100);
    // Bắt đầu lấy dữ liệu
    let mainUl = tab.locator('ul.shopee-search-item-result__items');
    let liTags = await mainUl.locator('li').all();
    for (let i = 0; i < liTags.length; i++) {
        let li = liTags[i];
        let aTag = await li.locator('a');
        let href = await aTag.getAttribute('href');
        let nameTag = await aTag.locator('[data-sqe="name"]');
        let names = await nameTag.locator('div').locator('div').allInnerTexts();
        let span = await aTag.locator('[aria-label="current price"]').locator('..').allInnerTexts();

        // Rating
        let ratingDiv = await aTag.locator('[data-sqe="rating"]');
        let rating = await aTag.locator('.shopee-rating-stars__stars > div').count();
        let sold = await ratingDiv.locator('..').nth(-1).innerText();
        products.push(new Product(names[0], href, rating, span.join(' '), sold));
    }
    if (curPage === 10) return;
    await loadNextPage(tab, curPage+1);
    await getProducts(tab, curPage + 1);
}

test('crawl', async ({page}) => {
    const browser = await firefox.launch({headless: false});
    page = await browser.newPage();

    await page.goto('https://shopee.vn/');

    // Get div target
    while (await page.locator('div.home-category-list__header').count() === 0)
        await delay(1000);
    let target = page.locator('div.home-category-list__header');

    // Get items
    while (await target.locator('li.image-carousel__item').count() === 0)
        await delay(1000);
    let items = target.locator('li.image-carousel__item');
    console.log(`found ${await items.count()} items`);

    // Close popup if has
    let popup = page.locator('div.shopee-popup__close-btn');
    if (await popup.count() === 1) {
        await popup.click();
        await delay(1000);
    }

    // Scroll down
    await page.mouse.wheel(10, 0);

    // Open new tab
    let categories = await items.all();
    let categorieNum = categories.length;
    categorieNum = 2;
    for (let index = 0; index < categorieNum; index++) {
        // xử lý từng tab 1
        let categoryElement = categories[index];
        await page.keyboard.down('Control')
        await categoryElement.click();
        // Chờ tới khi 1 tab được thiết lập và gắn vào context
        while (page.context().pages().length === 1)
            await delay(100);
        // Chuyển sang tab mới
        let curTab = page.context().pages()[1];
        await curTab.bringToFront();
        
        await getProducts(curTab);
        
        curTab.close();
        dump(products);
    }
    await browser.close();
});
//npx playwright test --project=firefox
//  await page.screenshot({ path: `screenshot.png` });