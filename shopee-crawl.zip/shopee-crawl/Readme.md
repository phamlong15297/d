# Crawl shopee

```shell
npm init playwright@latest
npx playwright test
```
File will be dumped into `dump.json`